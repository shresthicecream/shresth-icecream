// Lightweight JS: mobile nav, smooth scroll, reveal animations, testimonial auto-scroll, year
document.addEventListener('DOMContentLoaded', function(){
  // Year
  document.getElementById('year').textContent = new Date().getFullYear();

  // Mobile nav toggle
  const navToggle = document.getElementById('nav-toggle');
  const navLinks = document.getElementById('nav-links');
  navToggle && navToggle.addEventListener('click', () => {
    navLinks.classList.toggle('open');
    navToggle.classList.toggle('open');
  });

  // Smooth scrolling for in-page links
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', function(e){
      const target = document.querySelector(this.getAttribute('href'));
      if(target){ e.preventDefault(); target.scrollIntoView({behavior:'smooth', block:'start'}); }
    });
  });

  // Reveal on scroll using IntersectionObserver
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('reveal');
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: 0.12});

  document.querySelectorAll('.card, .section-title, .icon-card, .testimonial, .hero-image').forEach(el => {
    observer.observe(el);
  });

  // Testimonials simple auto-scroll
  const testContainer = document.getElementById('testimonials');
  if(testContainer){
    let scrollAmount = 0;
    const step = 320; // width of card
    let interval = setInterval(()=> {
      if(testContainer.scrollLeft >= testContainer.scrollWidth - testContainer.clientWidth - 2){
        // rewind
        testContainer.scrollTo({left:0, behavior:'smooth'});
      } else {
        testContainer.scrollBy({left: step, behavior:'smooth'});
      }
    }, 3500);

    testContainer.addEventListener('mouseenter', ()=> clearInterval(interval));
    testContainer.addEventListener('mouseleave', ()=> {
      interval = setInterval(()=> {
        if(testContainer.scrollLeft >= testContainer.scrollWidth - testContainer.clientWidth - 2){
          testContainer.scrollTo({left:0, behavior:'smooth'});
        } else {
          testContainer.scrollBy({left: step, behavior:'smooth'});
        }
      }, 3500);
    });
  }

  // Accessibility: close mobile nav when clicking a nav link
  document.querySelectorAll('.nav-links a').forEach(a => {
    a.addEventListener('click', ()=> {
      if(navLinks.classList.contains('open')) navLinks.classList.remove('open');
    });
  });
});